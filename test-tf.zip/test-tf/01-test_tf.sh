#!/usr/bin/env bash
#SBATCH -A naiss2023-22-642 -p alvis
#SBATCH --gpus-per-node=A40:1
#SBATCH -t 0-01:00:00

module purge
module load TensorFlow/2.11.0-foss-2022a-CUDA-11.7.0


python3 01-test_tf.py
