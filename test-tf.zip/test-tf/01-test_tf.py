import tensorflow as tf
import numpy as np

# 创建一些示例数据
data_size = 100
input_features = np.random.rand(data_size, 3)  # 3个输入特征
labels = np.random.randint(0, 2, size=(data_size,))  # 二分类标签

# 划分数据集为训练集和测试集
train_size = int(0.8 * data_size)
train_features, test_features = input_features[:train_size], input_features[train_size:]
train_labels, test_labels = labels[:train_size], labels[train_size:]

# 创建TensorFlow数据集对象
train_dataset = tf.data.Dataset.from_tensor_slices((train_features, train_labels))
test_dataset = tf.data.Dataset.from_tensor_slices((test_features, test_labels))

# 定义一些数据处理操作，例如乱序、分批和预取
batch_size = 32
train_dataset = train_dataset.shuffle(buffer_size=train_size).batch(batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)
test_dataset = test_dataset.batch(batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)

# 创建一个简单的模型
model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=(3,)),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

# 编译模型
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 训练模型
model.fit(train_dataset, epochs=5, validation_data=test_dataset)

# 评估模型
eval_results = model.evaluate(test_dataset)
print("Test Loss:", eval_results[0])
print("Test Accuracy:", eval_results[1])

# 进行预测
predictions = model.predict(test_dataset)

# 保存预测结果到文件
np.savetxt("predictions.csv", predictions, delimiter=",")

# 保存模型
model.save("my_model")
